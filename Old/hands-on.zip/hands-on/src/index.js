document.getElementById('target').addEventListener('click',function(){
    alert('変更OK!!');
});